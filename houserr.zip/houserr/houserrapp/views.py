from django.shortcuts import render, redirect
from django.contrib import messages

def home(request):
    return render(request, 'world.html')

def login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        # Check login credentials (replace with your authentication logic)
        if username == 'jainmudit696' and password == 'Mudit.2004':
            # Set session variable to indicate user is logged in
            request.session['username'] = username
            return redirect('services')
        else:
            messages.error(request, 'Invalid username or password. Please try again.')
    return redirect('home')

def register(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        # Handle user registration (replace with your registration logic)
        # For simplicity, I'm not including registration logic here
        messages.success(request, 'Registration successful! You can now login with your credentials.')
    return redirect('home')

def services(request):
    if 'username' not in request.session:
        return redirect('home')
    return render(request, 'services.html')

def book_service(request):
    return render(request, 'book.html')