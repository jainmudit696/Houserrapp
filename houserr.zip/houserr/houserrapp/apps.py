from django.apps import AppConfig


class HouserrappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'houserrapp'
